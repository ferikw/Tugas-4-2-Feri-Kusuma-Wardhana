import 'package:get/get.dart';

class Textcase extends GetxController {
  var text = "klik floating action buttom ".obs;

  void ubah() {
    if (text.value == text.value.toLowerCase()) {
      text.value = text.value.toUpperCase();
    } else {
      text.value = text.value.toLowerCase();
    }
  }
}
