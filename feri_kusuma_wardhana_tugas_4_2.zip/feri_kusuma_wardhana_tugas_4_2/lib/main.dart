import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:feri_kusuma_wardhana_tugas_4_2/page/page1.dart';
import 'package:feri_kusuma_wardhana_tugas_4_2/page/page2.dart';
import 'package:feri_kusuma_wardhana_tugas_4_2/page/page3.dart';
import 'package:feri_kusuma_wardhana_tugas_4_2/page/page4.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Feri Kusuma Wardhana',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: const Color.fromRGBO(255, 255, 255, 1),
        textTheme: GoogleFonts.poppinsTextTheme(),
      ),
      initialRoute: '/',
      getPages: [
        GetPage(name: '/', page: () => const Home()),
        GetPage(name: '/page1', page: () => Page1()),
        GetPage(name: '/page2', page: () => Page2()),
        GetPage(name: '/page3', page: () => Page3()),
        GetPage(name: '/page4', page: () => Page4()),
      ],
    );
  }
}

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('HOME',
            style: TextStyle(fontFamily: 'Poppins', color: Colors.white)),
        backgroundColor: Colors.green,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Get.toNamed('/page1');
              },
              style: ElevatedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                backgroundColor: const Color.fromARGB(255, 245, 240, 232),
                minimumSize: const Size(200, 50),
              ),
              child:
                  const Text('Page 1', style: TextStyle(fontFamily: 'Poppins')),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Get.toNamed('/page2');
              },
              style: ElevatedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                backgroundColor: const Color.fromARGB(255, 231, 231, 231),
                minimumSize: const Size(200, 50),
              ),
              child:
                  const Text('Page 2', style: TextStyle(fontFamily: 'Poppins')),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Get.toNamed('/page3');
              },
              style: ElevatedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                backgroundColor: const Color.fromARGB(255, 218, 219, 219),
                minimumSize: const Size(200, 50),
              ),
              child:
                  const Text('Page 3', style: TextStyle(fontFamily: 'Poppins')),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Get.toNamed('/page4');
              },
              style: ElevatedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                backgroundColor: const Color.fromARGB(255, 218, 216, 215),
                minimumSize: const Size(200, 50),
              ),
              child:
                  const Text('Page 4', style: TextStyle(fontFamily: 'Poppins')),
            ),
          ],
        ),
      ),
    );
  }
}
