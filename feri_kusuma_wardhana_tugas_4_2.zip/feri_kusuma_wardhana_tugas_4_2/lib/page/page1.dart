// ignore_for_file: use_key_in_widget_constructors, non_constant_identifier_names

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:feri_kusuma_wardhana_tugas_4_2/controler/controller.dart';

class Page1 extends StatelessWidget {
  final Textcase Ubahtext = Get.put(Textcase());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Page 1'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("Ini Page Uppercase atau Lowercase Berikut :"),
            const SizedBox(height: 40),
            Obx(
              () => Text(
                Ubahtext.text.value,
                style: const TextStyle(fontSize: 24.0),
              ),
            ),
            const SizedBox(height: 60),
            ElevatedButton(
              onPressed: () {
                Get.toNamed('/page2');
              },
              style: ElevatedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                backgroundColor: const Color.fromARGB(255, 255, 255, 255),
                minimumSize: const Size(200, 50),
              ),
              child: const Text('Pergi ke Page 2'),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Ubahtext.ubah();
        },
        child: const Icon(Icons.arrow_upward),
      ),
    );
  }
}
