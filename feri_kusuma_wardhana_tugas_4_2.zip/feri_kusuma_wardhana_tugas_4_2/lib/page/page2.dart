// ignore_for_file: use_key_in_widget_constructors

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Page2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Page 2'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("Ini Page Menunjukkan Snackbar :"),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                Get.snackbar(
                  'Feri SnackBar',
                  'Ini adalah SnackBar',
                  backgroundColor: Colors.blue,
                  colorText: Colors.white,
                );
              },
              style: ElevatedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                backgroundColor: const Color.fromARGB(255, 255, 255, 255),
                minimumSize: const Size(200, 50),
              ),
              child: const Text('Tunjukkan SnackBar'),
            ),
            const SizedBox(height: 60),
            ElevatedButton(
              onPressed: () {
                Get.toNamed('/page3');
              },
              child: const Text('Ayo ke Page 3'),
            ),
          ],
        ),
      ),
    );
  }
}
