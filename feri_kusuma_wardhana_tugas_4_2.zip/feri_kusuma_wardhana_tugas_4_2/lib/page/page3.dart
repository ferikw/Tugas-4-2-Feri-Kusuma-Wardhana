// ignore_for_file: use_key_in_widget_constructors

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Page3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Page 3'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("Ini Page Menunjukkan Dialog :"),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                Get.defaultDialog(
                  title: 'Dialog Feri',
                  content: const Text('Ini dialog Feri !'),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Get.back();
                      },
                      child: const Text('Close'),
                    ),
                  ],
                );
              },
              child: const Text('Tunjukkan  Dialog'),
            ),
            const SizedBox(height: 90),
            ElevatedButton(
              onPressed: () {
                Get.toNamed('/page4');
              },
              child: const Text('Pergi ke Page 4'),
            ),
          ],
        ),
      ),
    );
  }
}
